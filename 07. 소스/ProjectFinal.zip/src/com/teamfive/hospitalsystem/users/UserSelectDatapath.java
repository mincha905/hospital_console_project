package com.teamfive.hospitalsystem.users;

public class UserSelectDatapath {

	final public static String 회원 = "C:\\class\\java\\JavaTestRework\\src\\User\\회원에서옮겨가기.txt";
	
}
