package com.teamfive.hospitalsystem.admin;

public class AdminDataPath {

	final public static String reviewInfo = ".\\src\\com\\teamfive\\hospitalsystem\\data\\review.txt";
	final public static String hosptInfo = ".\\src\\com\\teamfive\\hospitalsystem\\data\\병원테스트.txt";
	final public static String docInfo = ".\\src\\com\\teamfive\\hospitalsystem\\data\\의사정보.txt";
	final public static String userInfo = ".\\src\\com\\teamfive\\hospitalsystem\\data\\user2.txt";
	final public static String reservInfo = ".\\src\\com\\teamfive\\hospitalsystem\\data\\예약정보.txt";

}
