package com.teamfive.hospitalsystem.mypage;

public class Login {

	// public static UserClass auth; // Login team
	// 4,ar6bo74,tCM92lPamFi,정경인,000131,2,01081111387,서울특별시 북구 제기동,ar6bo74

	public static UserClass auth = new UserClass("4", "abcd1234", "12345678", "정경인", "000131",
			"2", "01081111387", "서울특별시 북구 제기동", "abcd1234");


}
