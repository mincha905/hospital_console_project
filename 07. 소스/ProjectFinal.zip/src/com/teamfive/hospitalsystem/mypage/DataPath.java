package com.teamfive.hospitalsystem.mypage;

public class DataPath {
	
	final public static String 회원 = ".\\src\\com\\teamfive\\hospitalsystem\\data\\user1.txt";
	public final static String 리뷰 = ".\\src\\com\\teamfive\\hospitalsystem\\data\\review.txt";
	public final static String 예약 = ".\\src\\com\\teamfive\\hospitalsystem\\data\\reserve.txt";

}
