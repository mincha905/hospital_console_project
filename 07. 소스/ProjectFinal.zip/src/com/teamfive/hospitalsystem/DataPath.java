package com.teamfive.hospitalsystem;

public class DataPath {

	final public static String 회원 = ".\\src\\com\\teamfive\\hospitalsystem\\data\\user.txt";
	
}
