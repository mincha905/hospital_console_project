package com.teamfive.hospitalsystem.hospital.select;

public class DataPath {

	final public static String 병원찾기 = ".\\data\\FindHospital.txt";
	final public static String 시도 = ".\\data\\City.txt";
	final public static String 지역 = ".\\data\\ji.txt";
	final public static String 도로명 = ".\\data\\gu.txt";
	final public static String 선택 = ".\\data\\Select.txt";
	final public static String 진료과목 = ".\\data\\JinRo.txt";
	final public static String 증상별 = ".\\data\\증상.txt";
}
