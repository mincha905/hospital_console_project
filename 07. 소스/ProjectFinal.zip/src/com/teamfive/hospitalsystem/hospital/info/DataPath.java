package com.teamfive.hospitalsystem.hospital.info;

public class DataPath {
	final public static String 병원 = ".\\data\\병원.txt"; 
	final public static String 병원리뷰 = ".\\data\\병원리뷰.txt"; 
	
	final public static String 예약내역 = ".\\data\\예약내역.txt";
	final public static String user = ".\\data\\user.txt";


}
